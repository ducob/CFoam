import matplotlib.pyplot as plt
import scipy
from CFoamFunctions import * #Library containing CFoam related analysis functions
from copy import deepcopy #To copy data sets so variables instead of making references to


########## RANGE FUNCTION ##########
def min_max(list, first, last):
    return_list=[]
    max_val = 0
    for i in range(first,last):
        if  max(list[i]) > max_val:
            max_val = max(list[i])
    return_list.append(max_val)

    min_val = max_val
    for i in range(first,last):
        if min(list[i]) < min_val:
            min_val = min(list[i])
    return_list.append(min_val)

    return return_list

def temp_plot (Temp):
    ########## INITIALISE PLOT AND ADD DATA ##########
    fig = plt.figure()

    ax1 = fig.add_subplot(3, 1, 1)
    top_names = ["S1_LC", "S1", "S2", "S3", "S4", "S4_RC"]
    for i in range(1,7):
        ax1.plot(Temp[0], Temp[i], label=top_names[i-1])

    ########## TOP TITLE ##########
    ax1.set_title("Top Cu Temperature", fontsize=14, color='black')
    plt.ylabel("Temperature (deg C)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax1.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax1.yaxis.get_ticklabels():
        tick.set_fontsize(16)
    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ax2 = fig.add_subplot(3, 1, 2)
    bot_names = ["S5_RC", "S5", "S6", "S7", "S8", "S8_LC"]
    for i in range(7,13):
        ax2.plot(Temp[0], Temp[i], label=bot_names[i-7])

    ########## BOTTOM TITLE ##########
    ax2.set_title("Bottom Cu Temperature", fontsize=14, color='black')
    plt.ylabel("Temperature (deg C)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax2.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax2.yaxis.get_ticklabels():
        tick.set_fontsize(16)
    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ax2 = fig.add_subplot(3, 1, 3)
    gas_names = ["gas In", "gas Out", "Box", "Lab"]
    for i in range(13,17):
        ax2.plot(Temp[0], Temp[i], label=gas_names[i-13])

    ########## AMBIENT AND GAS TITLE ##########
    ax2.set_title("Gas and Ambient CFoam Temperature", fontsize=14, color='black')
    plt.ylabel("Temperature (deg C)", fontsize = 16)
    plt.xlabel("Time (s)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax2.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax2.yaxis.get_ticklabels():
        tick.set_fontsize(16)
    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ######### DISPLAY ##########
    plt.show()
    
def adc_plot ( Temp ):
    ########## INITIALISE PLOT AND ADD DATA ##########
    fig = plt.figure()

    ax1 = fig.add_subplot(3, 1, 1)
    top_names = ["S1", "S2", "S3", "S4"]
    for i in range(1,5):
        ax1.plot(Temp[0], Temp[i], label=top_names[i-1])

    ########## TOP TITLE ##########
    ax1.set_title("Top Voltage", fontsize=14, color='black')
    plt.ylabel("Voltage (V)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax1.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax1.yaxis.get_ticklabels():
        tick.set_fontsize(16)
        ax1.set_yticks(scipy.arange(min_max(Temp, 1, 5)[1]-0.05, min_max(Temp, 1, 5)[0]+0.05,0.02))
    
    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ax2 = fig.add_subplot(3, 1, 2)
    bot_names = ["S5", "S6", "S7", "S8"]
    for i in range(5,9):
        ax2.plot(Temp[0], Temp[i], label=bot_names[i-5])

    ########## BOTTOM TITLE ##########
    ax2.set_title("Bottom Voltage", fontsize=14, color='black')
    plt.ylabel("Voltage (V)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax2.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax2.yaxis.get_ticklabels():
        tick.set_fontsize(16)
        ax2.set_yticks(scipy.arange(min_max(Temp, 5, 9)[1]-0.05, min_max(Temp, 5, 9)[0]+0.05,0.02))
    
    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ax3 = fig.add_subplot(3, 1, 3)
    p_names = ["DP"]
    for i in range(9,10):
        ax3.plot(Temp[0], Temp[i], label=p_names[i-9])

    ########## AMBIENT AND GAS TITLE ##########
    ax3.set_title("Differential Pressure", fontsize=14, color='black')
    plt.ylabel("Delta P (mbar)", fontsize = 16)
    plt.xlabel("Time (s)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax3.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax3.yaxis.get_ticklabels():
        tick.set_fontsize(16)
        ax3.set_yticks(scipy.arange(min_max(Temp, 9, 10)[1]-0.05, min_max(Temp, 9, 10)[0]+0.1,0.1))
    
    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()


    ########## DISPLAY ##########
    plt.show()

def ps_plot ( Temp ):
    ########## INITIALISE PLOT AND ADD DATA ##########
    fig = plt.figure()

    ax1 = fig.add_subplot(2, 1, 1)
    vol_names = ["Top", "","", "Bottom"]
    for i in {2, 5}:
        ax1.plot(Temp[0], Temp[i], label=vol_names[i-2])

    ########## TOP TITLE ##########
    ax1.set_title("Power Supply Voltage", fontsize=14, color='black')
    plt.ylabel("Voltage (V)", fontsize = 16)
    ########## AXIS INFO ##########
    for tick in ax1.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax1.yaxis.get_ticklabels():
        tick.set_fontsize(16)
        ax1.set_yticks(scipy.arange(min_max(Temp, 2, 3)[1]-0.05, min_max(Temp, 2, 3)[0]+0.05,0.02))

    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ax2 = fig.add_subplot(2, 1, 2)
    cur_names = ["Top", "","", "Bottom"]
    for i in {3,6}:
        ax2.plot(Temp[0], Temp[i], label=cur_names[i-3])

    ########## BOTTOM TITLE ##########
    ax2.set_title("Power Supply Current", fontsize=14, color='black')
    plt.ylabel("Current (A)", fontsize = 16)
    plt.xlabel("Time (s)", fontsize=16)
    ########## AXIS INFO ##########
    for tick in ax2.xaxis.get_ticklabels():
        tick.set_fontsize(16)
    for tick in ax2.yaxis.get_ticklabels():
        tick.set_fontsize(16)
        ax2.set_yticks(scipy.arange(min_max(Temp, 3, 4)[1]-0.05, min_max(Temp, 3, 4)[0]+0.05,0.02))

    plt.legend(fontsize= 16, title='LEGEND')
    plt.grid()

    ########## DISPLAY ##########
    plt.show()
    
def simple_plot ( xarray, yarray ):
    ########## INITIALISE PLOT AND ADD DATA ##########
    fig = plt.figure()
    
    ax1 = fig.add_subplot(1,1,1)
    ax1.plot(xarray, yarray)
    plt.grid
    plt.show()

def htc_plot ( data1, data2, data3 ):
    powerArray = []
    for i in range(0,8):
        powerArray.append( mean(power_density(data1)[2]) )
    for i in range(0,8):
        powerArray.append( mean(power_density(data2)[2]) )
    for i in range(0,8):
        powerArray.append( mean(power_density(data3)[2]) )

    htcArray = []
    first = htc_point(data1)
    print first
    for i in range(0,8):
        htcArray.append( first[i] )
    print "Part 1: Done"
    print " "

    second = htc_point(data2)
    print second
    for i in range(0,8):
        htcArray.append( second[i] )
    print "Part 2: Done"
    print " "

    third = htc_point(data3)
    print third
    for i in range(0,8):
        htcArray.append( third[i] )
    print "Part 3: Done"
    print " "
    
    colors = ["#0000FF", "#33CC33", "#FF9933", "#FF0000"]
    for j in range(0, 3):
        for i in range(0, 4):
            plt.scatter(powerArray[(8*j)+i], htcArray[(8*j)+i], marker="^", c = colors[i], s=50)
        for i in range(4, 8):
            plt.scatter(powerArray[(8*j)+i], htcArray[(8*j)+i], marker="s", c = colors[i-4], s=50)

    plt.grid()
    plt.show()
    
def htc_plot2 ( data1, data2, data3, timeStart, timeEnd ):
    powerArray = []
    for i in range(0,8):
        powerArray.append( mean(power_density(data1)[2]) )
    for i in range(0,8):
        powerArray.append( mean(power_density(data2)[2]) )
    for i in range(0,8):
        powerArray.append( mean(power_density(data3)[2]) )

    htcArray = []
    first = htc_mean(data1, timeStart, timeEnd)
    print first
    for i in range(0,8):
        htcArray.append( first[i] )
    print "Part 1: Done"
    print " "

    second = htc_mean(data2, timeStart, timeEnd)
    print second
    for i in range(0,8):
        htcArray.append( second[i] )
    print "Part 2: Done"
    print " "

    third = htc_mean(data3, timeStart, timeEnd)
    print third
    for i in range(0,8):
        htcArray.append( third[i] )
    print "Part 3: Done"
    print " "
    
    colors = ["#0000FF", "#33CC33", "#FF9933", "#FF0000"]
    for j in range(0, 3):
        for i in range(0, 4):
            plt.scatter(powerArray[(8*j)+i], htcArray[(8*j)+i], marker="^", c = colors[i], s=50)
        for i in range(4, 8):
            plt.scatter(powerArray[(8*j)+i], htcArray[(8*j)+i], marker="s", c = colors[i-4], s=50)

    plt.grid()
    plt.show()

    
##### Plots GasIn(triangle), GasOut(square), avg copper(cirlce) and lab(cross) temperature, aswell as their lab environment corrected values  ####
def gas_comparisson( data1, data2, data3 ):
    i = int(16000 / step_size(data1)[0])
    tGasIn = [data1[2][13][i], data1[2][13][i], data1[2][13][i]]
    tGasInCor = [[data1[2][13][i] - data1[2][16][i], data2[2][13][i] - data2[2][16][i], data3[2][13][i] - data3[2][13][i]]]
    tGasOut = [data1[2][14][i], data1[2][14][i], data1[2][14][i]]
    tGasOutCor = [data1[2][14][i] - data1[2][16][i], data2[2][14][i] - data2[2][16][i], data3[2][14][i] - data3[2][16][i]]
    meanCu = [avg_temp(data1)[2][i], avg_temp(data2)[2][i], avg_temp(data3)[2][i]]
    Lab = [data1[2][16][i], data2[2][16][i], data3[2][16][i]]

    pdArray = [mean(power_density(data1)[2]), mean(power_density(data2)[2]), mean(power_density(data3)[2])]
    
    gi = plt.scatter(pdArray, tGasIn, marker = "^", s=60)
    go = plt.scatter(pdArray, tGasOut, marker = "s", s=60)
    mcu = plt.scatter(pdArray, meanCu, marker = "o", s=60)
    labe = plt.scatter(pdArray, Lab, marker = "x", s=60)
    plt.legend((gi, go, mcu, labe), ["Gas In", "Gas Out", "Mean Cu", "Lab"], scatterpoints=1)
    plt.grid()
    plt.show()

    gic = plt.scatter(pdArray, tGasInCor, marker = "^", s=60)
    goc = plt.scatter(pdArray, tGasOutCor, marker = "s", s=60)
    plt.legend((gic, goc), ["Gas In cor", "Gas Out cor"], scatterpoints=1)
    plt.grid()
    plt.show()