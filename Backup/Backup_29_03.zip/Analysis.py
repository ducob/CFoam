##########################################################################################
from ExtractData import import_data #Library for CFoam data input
from CFoamPlot import * #Library containing CFoam plot functions
from CFoamFunctions import * #Library containing CFoam related analysis functions
from copy import deepcopy #To copy data sets so variables instead of making references to

import matplotlib.pyplot as plt
import scipy as sp
import os.path
import numpy as np

execfile('CFoamMap.py') #Maps names to the integers given for the arrays in measurment files

# ##########################################################################################
#
data1 = import_data("16_03_2015", "_13_02_37", "_(20mbar).file")
data2 = import_data("16_03_2015", "_23_54_39", "_(20mbar).file")
data3 = import_data("17_03_2015", "_10_32_49", "_(20mbar).file")
#
# ##########################################################################################
#
# gas_comparisson( data1, data2, data3 )
# htc_plot( data1, data2, data3 )
#
# ##########################################################################################
#
# data1 = import_data("12_03_2015", "_10_28_02", "_(15mbar).file")
# data2 = import_data("12_03_2015", "_15_36_45", "_(15mbar).file")
# data3 = import_data("13_03_2015", "_09_26_17", "_(15mbar).file")
#
# ##########################################################################################
#
# gas_comparisson( data1, data2, data3 )
# htc_plot( data1, data2, data3 )
#
# ##########################################################################################
#
# data1 = import_data("10_03_2015", "_15_26_13", "_(10mbar).file")
# data2 = import_data("10_03_2015", "_21_21_48", "_(10mbar).file")
# data3 = import_data("11_03_2015", "_16_23_09", "_(10mbar).file")
#
# ##########################################################################################
#
# gas_comparisson( data1, data2, data3 )
# htc_plot( data1, data2, data3 )
#
# ##########################################################################################
#
#data1 = import_data("09_03_2015", "_10_32_15", "_(5mbar).file")
#data2 = import_data("09_03_2015", "_15_55_27", "_(5mbar).file")
# data3 = import_data("10_03_2015", "_09_49_04", "_(5mbar).file")
#
# ##########################################################################################
#
# gas_comparisson( data1, data2, data3 )
htc_plot( data1, data2, data3 )
#htc_plot2(data1, data2, data3, 0, 200)


