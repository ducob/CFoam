########## IMPORTS ##########
import csv
import os.path
import matplotlib.pyplot as plt
import csv
import numpy as np
import time
import shutil

src_folder = "/Volumes/detrd/ducob/CFOAM_DATA/CFOAM/"

