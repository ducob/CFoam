import copy
execfile('CFoamMap.py')

##########           ##########
########## FUNCTIONS ##########
##########           ##########


########## MATH FUNC ##########
def sum(list):
    sum = 0
    for i in range(0, len(list)):
        sum = sum + list[i]
    return sum

def mean(list):
    sum = 0
    for i in range(0, len(list)):
        sum = sum + list[i]
    return sum / len(list)
    
def mean_section(list, a, b):
    sum = 0
    for i in range(a, b):
        sum = sum + list[i]
    return sum / (b-a)

def variance(list):
    average = mean(list)
    variance = 0
    for i in list:
        variance = variance + ((average - i)**2)
    return variance / len(list)

def std_deviation(list):
    return variance(list) ** 0.5
    
########## CFOAM Constants ##########
A = 18.73
R_probe_i = [5., 5., 5., 5., 5., 5., 5., 5.]
R_strip_j = [15., 15., 15., 15., 15., 15., 15., 15.]
R_probe_top = [5., 5., 5., 5.]
R_strip_top = [15., 15., 15., 15.]
R_probe_bot = [5., 5., 5., 5.]
R_strip_bot = [15., 15., 15., 15.]
    
########## CFOAM FUNC ##########
def power_correction(temperature):
    #slope = 0.097 #Frist correction measurement
    #slope = 0.105 #second correction measurement
    slope = 0.1032 #Third correction measurement (R = factory values)
    #intercept = -2.28 #First correction measurement
    #intercept = -2.524 #second correction measurement 
    intercept = -2.41107 #Third correction measurement (R = factory values)
    return slope*temperature + intercept

def power ( data ):
    Adc, Ps, Temp = data

    P_strip_top = [[] for x in xrange(4)]
    P_strip_bot = [[] for x in xrange(4)]
    
    for i in range(0,4):
        for j in range(0, len(Adc[0])):
            P_strip_top[i].append( pow(Adc[i+1][j]/R_probe_top[i], 2)*R_strip_top[i])
            P_strip_bot[i].append( pow(Adc[i+5][j]/R_probe_bot[i], 2)*R_strip_bot[i])        
    
    P_top = []
    P_top_step = 0
    P_bot = []
    P_bot_step = 0
    for i in range(0, len(Adc[0])):
        for j in range(0, 4):
            P_top_step += P_strip_top[j][i]
            P_bot_step += P_strip_bot[j][i]
        P_top.append(P_top_step)
        P_bot.append(P_bot_step)
        P_top_step = 0
        P_bot_step = 0
        
    return P_strip_top, P_strip_bot, P_top, P_bot

### power_density, returns the power density of the 8 strips ###
def power_density( data ):
    Adc, Ps, Temp = data
    P_strip_top, P_strip_bot, P_top, P_bot = power(data)

    PD_top = []
    PD_bot = []
    PD_tot = []
    for i in range(0, len(P_top)):
        PD_top.append(P_top[i]/(4*A))
        PD_bot.append(P_bot[i]/(4*A))
        PD_tot.append( (P_top[i]+P_bot[i])/(8*A) )
        
    return PD_top, PD_bot, PD_tot

def power_density_strip ( data ):
    Adc, Ps, Temp = data
    P_strip_top, P_strip_bot, P_top, P_bot = power(data)
    
    Top_Strip_PD = [[] for x in xrange(4)]
    Bot_Strip_PD = [[] for x in xrange(4)]
    for i in range(0, 4):
        for j in range(0, len(Adc[0])):
            Top_Strip_PD[i].append( P_strip_top[i][j]/A )
            Bot_Strip_PD[i].append( P_strip_bot[i][j]/A )
    return Top_Strip_PD, Bot_Strip_PD
            
### Power_print, prints the power and power density of the 8 strips ###
def power_print ( data ):
    Adc, Ps, Temp = data
    P_strip_top, P_strip_bot, P_top, P_bot = power(data)
     
    # Fill and Print out of Power per strip (calculated with voltage probe data)
    print " "
    print "-------------"
    print " "
    for i in range(0,4):
        print "Power in strip", i+1, ": ", mean(P_strip_top[i]), " W"
    for i in range(0,4):
        print "Power in strip", i+5, ": ", mean(P_strip_bot[i]), " W"
    print "===="

    # Calculation of total power and Print Out
    total_pow = mean(P_top) + mean(P_bot)
    print "Total power on top: ", mean(P_top), " W"
    print "Total power on bottom: ", mean(P_bot), " W"
    print "Total power on CFOAM device: ", total_pow, " W"
    print "Total power by PS: ", mean(Ps[2])*mean(Ps[3]) + mean(Ps[5])*mean(Ps[6])
    print " "
    print "-------------"
    print " "

    PD_top = mean(P_top)/(4*A)
    PD_bot = mean(P_bot)/(4*A)
    PD_avg = (PD_top + PD_bot)/2
    # Power density calculation
    for i in range(0,4):
        print "Power density in strip", i+1, ": ", mean(P_strip_top[i])/A, " W/cm2"
    for i in range(0,4):
        print "Power density in strip", i+5, ": ", mean(P_strip_bot[i])/A, " W/cm2"
    print "===="
    print "Power density on top: ", PD_top, " W/cm2"
    print "Power density on bottom: ", PD_bot, " W/cm2"
    print "Average power density on CFOAM device: ", PD_avg, " W/cm2"
    print ""
    print "-------------"
    print ""
    return None

def avg_temp ( data ):
    Adc, Ps, Temp = data
    
    T_top_avg = []
    for i in range(0, len(Temp[0])):
        T_top_avg.append( (Temp[1][i] + Temp[2][i] + Temp[3][i] + Temp[4][i] + Temp[5][i] + Temp[6][i])/6 )
    T_bot_avg = []
    for i in range(0, len(Temp[0])):
        T_bot_avg.append( (Temp[7][i] + Temp[8][i] + Temp[9][i] + Temp[10][i] + Temp[11][i] + Temp[12][i])/6 )
    
    T_avg = []
    for i in range(0, len(Temp[0])):
        T_avg.append((T_top_avg[i]+T_bot_avg[i])/2)
    
    return T_top_avg, T_bot_avg, T_avg

def flow_func(Power, foam_temperature, gas_in, gas_out):
    rho_gas = 1.1839        #in g/L @ 25 deg C
    c_v_gas = 1.012         #in J/(g*K)
    delta_T = gas_out - gas_in

    LPS = (Power - power_correction(foam_temperature))/(rho_gas * c_v_gas * delta_T)    #Litre per second
    LPM = LPS * 60  #Litre per minute
    return LPM

def flow( data ):
    Adc, Ps, Temp = data
    P_strip_top, P_strip_bot, P_top, P_bot = power(data)
    T_top_avg, T_bot_avg, T_avg = avg_temp(data)
    
    
    Flow_i = []
    for i in range(0, len(Temp[0])):
        Flow_i.append( flow_func(P_top[i]+P_bot[i], (T_top_avg[i]+T_bot_avg[i])/2, Temp[13][i], Temp[14][i]) )
    return Flow_i

### step_size, returns the increments of the array for all steps ###
def step_size( data ):
    Adc, Ps, Temp = data
    list = Temp[0]
    stepsize = []
    for i in range(0, len(list)-1):
        stepsize.append(list[i+1] - list[i])
    return stepsize

### step_size, returns the increments of the array for all steps ###
def correction ( Temp ):
    for j in range(1, 17):
        for i in range(0, len(Temp[0])):
            Temp[j][i] = Temp[j][i] - Temp[13][i]
    return Temp
    
### htc_point, returns the htc of a data set for all strips calculated at one sample point ###
def htc_point(data):
    adc, ps, temp = data
    stable_point = int(16000 / step_size(data)[0])

    ##########################################################################################
    
    pdTop, pdBot = power_density_strip(data)
    
    ##########################################################################################
    
    i = stable_point
    gasIn = temp[13][i]
    gasOut = temp[14][i]
    delT = gasOut - gasIn
    
    
    htcS1 = pdTop[0][i] / (temp[5][i] - (gasIn+ (1./8.)*delT))
    htcS2 = pdTop[1][i] / (temp[4][i] - (gasIn+(3./8.)*delT))
    htcS3 = pdTop[2][i] / (temp[3][i] - (gasIn+(5./8.)*delT))
    htcS4 = pdTop[3][i] / (temp[2][i] - (gasIn+(7./8.)*delT))

    htcS5 = pdBot[0][i] / (temp[8][i] - (gasIn+(1./8.)*delT))
    htcS6 = pdBot[1][i] / (temp[9][i] - (gasIn+(3./8.)*delT))
    htcS7 = pdBot[2][i] / (temp[10][i] - (gasIn+(5./8.)*delT))
    htcS8 = pdBot[3][i] / (temp[11][i] - (gasIn+(7./8.)*delT))

    return htcS1, htcS2, htcS3, htcS4, htcS5, htcS6, htcS7, htcS8
    
### htc_mean, returns the htc of a data set for all strips calculated by taking the average of a specified domain ###
def htc_mean (data, timeStart, timeEnd):
    adc, ps, temp = data
    pdTop, pdBot = power_density_strip(data)
    stepsize = step_size(data)[0]

    pointStart = int(timeStart / stepsize)
    pointEnd = int(timeEnd / stepsize)
    output = "array"

    ##########################################################################################

    gasIn = temp[13]
    gasOut = temp[14]
    delT = [a-b for a, b in zip(gasOut, gasIn)]

    ##########################################################################################

    htcS1, htcS2, htcS3, htcS4, htcS5, htcS6, htcS7, htcS8 = ([] for i in range(8))

    for i in range(pointStart, pointEnd):
        htcS1.append( pdTop[0][i] / (temp[5][i] - (gasIn[i] + (1./8.)*delT[i])) )
        htcS2.append( pdTop[1][i] / (temp[4][i] - (gasIn[i] + (3./8.)*delT[i])) )
        htcS3.append( pdTop[2][i] / (temp[3][i] - (gasIn[i] + (5./8.)*delT[i])) )
        htcS4.append( pdTop[3][i] / (temp[2][i] - (gasIn[i] + (7./8.)*delT[i])) )

        htcS5.append( pdBot[0][i] / (temp[8][i] - (gasIn[i] + (1./8.)*delT[i])) )
        htcS6.append( pdBot[1][i] / (temp[9][i] - (gasIn[i] + (3./8.)*delT[i])) )
        htcS7.append( pdBot[2][i] / (temp[10][i] - (gasIn[i] + (5./8.)*delT[i])) )
        htcS8.append( pdBot[3][i] / (temp[11][i] - (gasIn[i] + (7./8.)*delT[i])) )

    ##########################################################################################
    
    if(output == "array"):
        return htcS1, htcS2, htcS3, htcS4, htcS5, htcS6, htcS7, htcS8
   
    if(output == "number"):
        htcS1 = mean(htcS1)
        htcS2 = mean(htcS2)
        htcS3 = mean(htcS3)
        htcS4 = mean(htcS4)
        
        htcS5 = mean(htcS5)
        htcS6 = mean(htcS6)
        htcS7 = mean(htcS7)
        htcS8 = mean(htcS8)
        
        return htcS1, htcS2, htcS3, htcS4, htcS5, htcS6, htcS7, htcS8 
   
   
    
    
    
    